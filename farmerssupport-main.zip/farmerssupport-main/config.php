<?php
    $con=mysqli_connect("localhost","root","","vitap") or die('unable to connect');
?>  