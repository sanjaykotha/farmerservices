

<!DOCTYPE html>
<html>
  <head>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.food-munch-logo {
  width: 230px;
  height: 150px;
}
#navItem1 {
  color: #323f4b;
  font-family: "Roboto";
}
#navItem2 {
  color: #323f4b;
  font-family: "Roboto";
}
#navItem3 {
  color: #323f4b;
  font-family: "Roboto";
}
#navItem4 {
  color: #323f4b;
  font-family: "Roboto";
}
.banner-section-bg-container {
  background-image: url("https://d1tgh8fmlzexmh.cloudfront.net/ccbp-responsive-website/foodmunch-banner-bg.png");
  height: 100vh;
  background-size: cover;
}
.banner-heading {
  color: white;
  font-family: "Roboto";
  font-size: 45px;
  font-weight: 300;
}
.banner-caption {
  color: #f5f7fa;
  font-family: "Roboto";
  font-size: 24px;
  font-weight: 300;
}
.b1{
    margin: 2px;
}
.xyz
    {
        background-color:#00FF33;
        height:25px;
    }
    .abc2 
    {
        text-align: center;
        font-family: italic;
        padding:40px;
        color:green;
    }
    .abc3 
    {
        padding:30px;
        padding-top:10px;
        font-size:15px;
        display:flex;
        text-align:justify;
        justify-content:center;
    }
    .abc4
    {
        text-align: center;
        font-family: italic;
        padding:20px;
        color:blue;
    }
    .container1 
    {
        background-color: #a6c567;
    }
</style>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous"/>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body class="body1">
    <div class="container1">
    <nav class="navbar navbar-expand-lg navbar-light  bg-white">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img
            src="Farm.jpg"
            class="food-munch-logo"
          />
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav ml-auto">
            <div class="b1">
            <a href="home.php"><button type="button pd-5" class="btn btn-primary" >HOME</button></a></div>
            <div class="b1">
            <a href="#mahesh"><button type="button" class="btn btn-primary">ABOUT US</button></a></div>
            <div class="b1">
            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle dropdown-toggle-split" type="button" data-toggle="dropdown" aria-expanded="false">Farmers     
                <span class="caret"></span></button>
                <ul class="dropdown-menu">
                  <li><a href="farmerpageregister.php"> Registration</a></li>
                  <li><a href="farmerpagelogin.php">Login</a></li>
                </ul>
              </div>
              </div>
              <div class="b1">
              <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Business-Man
                <span class="caret"></span></button>
                <ul class="dropdown-menu">
                  <li><a href="busregister.php">Registration</a></li>
                  <li><a href="buslogin.php">Login</a></li>
                </ul>
              </div>
              </div>
              <div class="b1">
              <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Farming Tools
                <span class="caret"></span></button>
                <ul class="dropdown-menu">
                  <li><a href="toolreg.php">Registration</a></li>
                  <li><a href="toollogin.php">Login</a></li>
                </ul>
              </div>
              </div>
          </div>
          
        </div>
      </div>
    </nav>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="Farm5.jpg" style="width:100%;height:500px" alt="...">
          </div>
          <div class="carousel-item">
            <img src="Farm2.jpg" style="width:100%;height:500px" alt="...">
          </div>
          <div class="carousel-item">
            <img src="Farm3.jpg"  style="width:100%;height:500px" alt="...">
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
   </div>
   <div class="abc">
    <h1 class="abc2">IMPORTANCE OF AGRICULTURE</h1>
    <p class="abc3">Agriculture or farming is the practice of cultivating plants and livestock. Agriculture was the key development in the rise of sedentary human civilization, whereby farming of domesticated species created food surpluses that enabled people to live in cities. The history of agriculture began thousands of years ago. After gathering wild grains beginning at least 105,000 years ago, nascent farmers began to plant them around 11,500 years ago. Sheep, goats, pigs and cattle were domesticated over 10,000 years ago. Plants were independently cultivated in at least 11 regions of the world. Industrial agriculture based on large-scale monoculture in the twentieth century came to dominate agricultural output, though about 2 billion people still depended on subsistence agriculture.</p></div>
    <div class="abc1">
    <h1 class="abc4" id="mahesh">ABOUT US</h1>
    <p class="abc3"> E-Agriculture & Farming is actually an online user-friendly platform which focus on conversion of manual farming totally.Farmer Portal facilitates a single window solution to the farmers and stakeholders to disseminate the information about the Seed, Farm Machinery, Fertilizers, Farm Dealers.This website includes business login to display his purchase rates.</p>
    </div>

  
  </body>
</html>